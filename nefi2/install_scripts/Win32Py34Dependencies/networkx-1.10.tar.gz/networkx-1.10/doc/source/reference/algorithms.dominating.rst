***************
Dominating Sets
***************

.. automodule:: networkx.algorithms.dominating
.. autosummary::
   :toctree: generated/

   dominating_set
   is_dominating_set
